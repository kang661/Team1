create table member_food_tb(
    member_id varchar2(100) primary key,
	member_pw varchar2(100) not null,  
	member_nm varchar2(100) not null
)

