package com.onetop.food.repository;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.onetop.food.vo.BoardVO;

@Repository
public class BoardRepository {
	
	@Autowired
	private SqlSession session;

	public int writeBoard(BoardVO newBoard) {
		int result = 0;
		BoardMapper mapper = null;
		
		try {
			mapper = session.getMapper(BoardMapper.class);
			
			result = mapper.writeBoard(newBoard);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
}
