package com.onetop.food.vo;

import lombok.Data;

@Data
public class BoardVO {
	
	private int boardNum;
	private String boardTitle;
	private String storeAdd;
	private String storeTel;
	private String storetime;
	private String boardContent;
	private String memberId;
	private String boardDate;
	private String boardMap;
	private String originalFilename;
	private String savedFilename;
}
