package com.onetop.food.repository;

import com.onetop.food.vo.BoardVO;

public interface BoardMapper {

	int writeBoard(BoardVO newBoard);

}
