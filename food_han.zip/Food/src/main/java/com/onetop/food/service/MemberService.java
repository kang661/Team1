package com.onetop.food.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onetop.food.repository.MemberRepository;
import com.onetop.food.vo.MemberVO;


@Service
public class MemberService {

	@Autowired
	private MemberRepository rep;

	public boolean join(String userId, String userPw, String userNm) 
	{
			MemberVO newMember = new MemberVO();
			newMember.setUserId(userId);
			newMember.setUserPw(userPw);
			newMember.setUserNm(userNm);
			return rep.join(newMember) > 0;
		}

	public String login(String userId, String userPw) 
	{
		MemberVO loginMember = new MemberVO();
		loginMember.setUserId(userId);
		loginMember.setUserPw(userPw);
		return rep.login(loginMember);
	}

	public String idChk(String idChk) 
	{
		
		return rep.idChk(idChk);
	}
		
}

