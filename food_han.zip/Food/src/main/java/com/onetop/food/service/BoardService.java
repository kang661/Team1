package com.onetop.food.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.onetop.food.repository.BoardRepository;
import com.onetop.food.vo.BoardVO;

@Service
public class BoardService {
	
	@Autowired
	private BoardRepository rep;

	public boolean writeBoard(BoardVO newBoard, String memberId, String originalFilename, String savedFilename) {
		newBoard.setMemberId(memberId);
		newBoard.setOriginalFilename(originalFilename);
		newBoard.setSavedFilename(savedFilename);
		
		return rep.writeBoard(newBoard) > 0;
	}
}
