package com.onetop.food.repository;

import com.onetop.food.vo.MemberVO;

public interface MemberMapper {

	int join(MemberVO newMember);

	String login(MemberVO loginMember);

	String idChk(String idChk);

}
