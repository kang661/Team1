package com.onetop.food.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.onetop.food.service.MemberService;

@Controller
@RequestMapping(value = "/member")
public class MemberController {

	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);

	@Autowired
	private MemberService service;
	@RequestMapping(value = "/join", method = RequestMethod.GET)
	public String join()
	{
		logger.info("join메소드 실행(GET)");
		return "member/join";	
	}
	@ResponseBody
	@RequestMapping(value = "/idChk", method = RequestMethod.GET)
	public String idChk(String idChk)
	{
		logger.info("idChk메소드실행(GET)");
		logger.info("idChk: {}", idChk);
		String userId = service.idChk(idChk);
		logger.info("userId: {}", userId);
		if(userId == null)
		{
			logger.info("회원가입가능");
			return "available";
		}
		else
		{
			logger.info("회원가입불가");
			return null;
		}
		
	}
	@RequestMapping(value = "/join", method = RequestMethod.POST)
	public String join(String userId, String userPw, String userNm)
	{
		logger.info("join메소드 실행(post)");
		logger.info("userId: {}", userId);
		logger.info("userPw: {}", userPw);
		logger.info("userNm: {}", userNm);
		boolean result = service.join(userId, userPw, userNm);
		String returnUrl = "member/join";
		if(result)
		{
			logger.info("회원가입성공");
			returnUrl = "redirect:/member/login";
		}
		else
		{
			logger.info("회원가입실패");
		}
		return returnUrl;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login()
	{
		logger.info("login 메소드실행(GET)");
		return "member/login"; 
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(String userId, String userPw, HttpSession session)
	{
		logger.info("login 메소드실행(POST)");
		
		logger.info("userId: {}", userId);
		logger.info("userPw: {}", userPw);
	
		String userNm = service.login(userId, userPw);
		logger.info("userNm: {}", userNm);
		
		if(userNm != null)
		{
			logger.info("로그인 성공");
			session.setAttribute("userNm", userNm);
		}
		else
		{
			logger.info("로그인 실패");
		}
		return "redirect:/";
	}
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session)
	{
		logger.info("logout 메소드실행(GET)");
		session.removeAttribute("memberNm");
		return "redirect/";
	}

}
