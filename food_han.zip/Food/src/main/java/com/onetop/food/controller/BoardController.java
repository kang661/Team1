package com.onetop.food.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.onetop.food.service.BoardService;
import com.onetop.food.utill.FileService;
import com.onetop.food.vo.BoardVO;

@Controller
@RequestMapping(value = "/board")
public class BoardController {

	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	private static final String UPLOAD_PATH = "C:\\Upload Files\\";
	
	private BoardService service;
	
	@RequestMapping(value="/jList", method=RequestMethod.GET)
	public String jList() {
		logger.info("jList 메소드 실행(GET)");
		
		return "board/jList";
	}
	
	@RequestMapping(value="/writeBoard", method=RequestMethod.GET)
	public String writeBoard() {
		logger.info("writeBoard 메서드 실행(GET)");
		
		return "board/writeBoard";
	}
	
	@RequestMapping(value="/writeBoard", method = RequestMethod.POST)
	public String writeBoard(BoardVO newBoard, @RequestParam("uploadFile") MultipartFile mfile, HttpSession session) {
		logger.info("writeBoard 메소드 실행(POST)");
		
		logger.info("newBoard : {}", newBoard);
		logger.info("mfile : {}", mfile);
		String originalFilename = null;
		if( mfile != null ) {
			originalFilename = mfile.getOriginalFilename();
			logger.info("originalFilename : {}", mfile.getOriginalFilename());
		}
		
		String savedFilename = FileService.saveFile(mfile, UPLOAD_PATH);
		if( savedFilename != null) {
			logger.info("파일 저장 성공");
			logger.info("저장된 파일명 : {}", savedFilename);
		} else {
			logger.info("파일 저장 실패");
		}
		
		String memberId = (String) session.getAttribute("memberId");
		logger.info("memberId : {}", memberId);
		
		boolean result = service.writeBoard(newBoard, memberId, originalFilename, savedFilename);
		String returnUrl = null;
		if( result ) {
			logger.info("게시글 작성 성공");
			returnUrl = "redirect:/board/jList";
		} else {
			logger.info("게시글 작성 실패");
			returnUrl = "redirect:/board/writeBoard";
		}
		
		return returnUrl;
	}
}
