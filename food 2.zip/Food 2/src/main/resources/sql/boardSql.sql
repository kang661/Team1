create table board_food_tb (
    board_num number primary key,
    board_title varchar2(1000) not null,
    board_content varchar2(3000),
    member_id varchar2(100) references member_food_tb(member_id),
    board_date date default sysdate,
    board_map varchar2(100),
    original_filename varchar2(1000)
);

create sequence board_food_seq;

create table reply_food_tb (
	board_num number references board_food_tb,
	member_id varchar2(100) references member_food_tb(member_id),
	reply_content varchar2(1000),
	reply_indate date default sysdate
);