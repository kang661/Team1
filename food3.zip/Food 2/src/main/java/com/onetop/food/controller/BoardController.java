package com.onetop.food.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.onetop.food.service.BoardService;
import com.onetop.food.utill.PageNavigator;
import com.onetop.food.vo.BoardVO;
import com.onetop.food.vo.ReplyVO;

@Controller
@RequestMapping(value = "/board")
public class BoardController {

	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

	private static final int COUNT_PER_PAGE = 10; // 한 페이지 당 보여줄 최대 게시글 수
	private static final int PAGE_PER_GROUP = 5; // 한 그룹 당 보여줄 최대 페이지 수

	@Autowired
	private BoardService service;

	@RequestMapping(value = "/jList", method = RequestMethod.GET)
	public String jList(@RequestParam(defaultValue = "1") int currentPage, Model model) {
		logger.info("jList 메소드(GET)");

		// 사용자가 보길 원하는 게시판 페이지 수를 확인(기본값 1)
		logger.info("현재 페이지(currentPage): {}", currentPage);

		// 검색종류 및 검색어를 입력해서 DB에서 총 게시글 수를 가져옴
		int totalRecordsCount = service.getTotalRecordsCount();
		logger.info("전체 게시글 수(totalRecordsCount): {}", totalRecordsCount);

		// 페이징 처리를 위한 내비게이터 객체 생성
		PageNavigator navi = new PageNavigator(COUNT_PER_PAGE, PAGE_PER_GROUP, currentPage, totalRecordsCount);
		logger.info("생성된 페이지 내비게이터(navi): {}", navi);
		model.addAttribute("navi", navi);

		ArrayList<BoardVO> result = service.readJList(navi.getStartRecord(), COUNT_PER_PAGE);
		logger.info("list: {}", result);
		model.addAttribute("list", result);

		return "/board/jList";
	}

	@RequestMapping(value = "/searchBoard", method = RequestMethod.GET)
	public String searchBoard(String searchType, String searchWord, Model model) {
		logger.info("searchBoard 메소드(GET)");

		ArrayList<BoardVO> result = service.searchBoard(searchType, searchWord);
		logger.info("list: {}", result);
		model.addAttribute("list", result);

		return "/board/jList";
	}

	// 읽기 기능
	@RequestMapping(value = "/readBoard", method = RequestMethod.GET)
	public String boardList(int boardNum, Model model) {
		logger.info("readBoard 메소드 실행(GET)");

		// list에서 받아온 게시글 번호 확인
		logger.info("boardNum: {}", boardNum);

		// 게시글 번호로 데이터 가져오기
		BoardVO board = service.readBoard(boardNum);
		logger.info("board: {}", board);

		// 게시글 데이터를 jsp에서 출력하기 위해 모델에 담기
		model.addAttribute("title", board.getBoardTitle());
		model.addAttribute("board", board);

		// 게시글 번호 이용해서 댓글 데이터 가져오기
		ArrayList<ReplyVO> replyList = service.getReplyList(boardNum);
		logger.info("replyList: {}", replyList);

		// 댓글 데이터 jsp에서 출력 위해 모델에 담기
		model.addAttribute("replyList", replyList);

		return "board/readBoard";
	}

	// 수정페이지 이동
	@RequestMapping(value = "/updateBoard", method = RequestMethod.GET)
	public String updateBoard(int boardNum, Model model) {
		logger.info("updateBoard 메소드 실행 (GET)");

		logger.info("boardNum: {}", boardNum);

		BoardVO board = service.readBoard(boardNum);
		logger.info("board: {}", board);

		model.addAttribute("board", board);

		return "board/updateBoard";
	}

	// 수정하기
	@RequestMapping(value = "/updateBoard", method = RequestMethod.POST)
	public String updateBoard(String title) {
		logger.info("updateBoard 메소드 실행 (POST)");

		return "board/readBoard";
	}

	// 삭제하기
	@RequestMapping(value = "/deleteBoard", method = RequestMethod.GET)
	public String deleteBoard(int boardNum, HttpSession session) {
		logger.info("deleteBoard 메소드 실행 (GET)");

		logger.info("boardNum: {}", boardNum);

		String memberId = (String) session.getAttribute("memberId");
		logger.info("memberId: {}", memberId);

		BoardVO board = new BoardVO();
		board.setMemberId(memberId);
		board.setBoardNum(boardNum);

		boolean result = service.deleteBoard(board);
		if (result) {
			logger.info("게시글 삭제 성공");
		} else {
			logger.info("게시글 삭제 실패");
		}

		return "redirect:/board/jList?=" + memberId;
	}

	// 추천하기
	@ResponseBody
	@RequestMapping(value = "/likeCnt", method = RequestMethod.GET) 
		public String likeCnt(int boardNum) {
		logger.info("likeCnt 메소드 실행 (GET)");
		
		logger.info("boardNum: {}", boardNum);
		
		int likeCnt = service.likeCnt(boardNum);
		logger.info("likeCnt: {}", likeCnt);
		
		return Integer.toString(likeCnt); 
	}

	// 댓글 쓰기 기능
	@ResponseBody
	@RequestMapping(value = "/writeReply", method = RequestMethod.POST)
	public ArrayList<ReplyVO> writeReply(int boardNum, String replyContent, HttpSession session) {
		logger.info("writeReply 메소드 실행 (POST)");

		logger.info("boardNum: {}", boardNum);
		logger.info("replyContent: {}", replyContent);

		// session에 저장된 로그인 정보 가져오기
		String memberId = (String) session.getAttribute("loginId");

		boolean result = service.writeReply(boardNum, memberId, replyContent);
		logger.info("댓글 작성 결과: {}", result);

		// 게시글 번호 이용해서 댓글 데이터 가져오기
		ArrayList<ReplyVO> replyList = service.getReplyList(boardNum);
		
		logger.info("replyList: {}", replyList);

		return replyList;
	}

}
