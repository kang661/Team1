package com.onetop.food.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onetop.food.repository.BoardRepository;
import com.onetop.food.vo.BoardVO;
import com.onetop.food.vo.ReplyVO;

@Service
public class BoardService {
	
	@Autowired
	private BoardRepository rep;

	public ArrayList<BoardVO> readJList(int startRecord, int countPerPage) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("startRecord", startRecord);
		map.put("countPerPage", countPerPage);
		
		return rep.readJList(map);
	}

	public ArrayList<BoardVO> searchBoard(String searchType, String searchWord) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("searchType", searchType);
		map.put("searchWord", searchWord);
		
		return rep.searchBoard(map);
	}

	public int getTotalRecordsCount() {
		
		return rep.getTotalRecordsCount();
	}
	
	// 읽기 기능
	public BoardVO readBoard(int boardNum) {
		
		return rep.readBoard(boardNum);
	}
	
	// 삭제 기능
	public boolean deleteBoard(BoardVO board) {
		
		return rep.deleteBoard(board) > 0;
	}

	// 추천 기능
	 public int likeCnt(int boardNum) {
	 
		 return rep.likeCnt(boardNum);
	 }


	// 댓글 출력 기능
	public ArrayList<ReplyVO> getReplyList(int boardNum) {
		
		return rep.getReplyList(boardNum);
	}

	// 댓글 쓰기 기능
	public boolean writeReply(int boardNum, String memberId, String replyContent) {
		
		ReplyVO newReply = new ReplyVO();
		newReply.setBoardNum(boardNum);
		newReply.setMemberId(memberId);
		newReply.setReplyContent(replyContent);
		
		return rep.writeReply(newReply) > 0;
	}



}
