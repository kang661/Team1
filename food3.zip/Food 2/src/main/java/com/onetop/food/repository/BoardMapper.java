package com.onetop.food.repository;

import java.util.ArrayList;
import java.util.HashMap;

import com.onetop.food.vo.BoardVO;
import com.onetop.food.vo.ReplyVO;

public interface BoardMapper {

	ArrayList<BoardVO> readJList(HashMap<String, Object> map); // 일본 리스트 불러오기

	ArrayList<BoardVO> searchBoard(HashMap<String, Object> map); // 검색기능 

	int getTotalRecordsCount(); // 페이징

	// 읽기 기능
	BoardVO readBoard(int boardNum);
	
	// 수정기능

	// 삭제 기능
	int deleteBoard(BoardVO board);
	
	// 추천 기능
	int likeCnt(int boardNum);

	// 댓글 출력 기능
	ArrayList<ReplyVO> getReplyList(int boardNum);

	// 댓글 추가 기능
	int writeReply(ReplyVO newReply);





}
