create table board_food_tb (
    board_num number primary key,
    board_title varchar2(1000) not null,
    board_content varchar2(3000),
    member_id varchar2(100) references member_food_tb(member_id),
    board_date date default sysdate,
    board_map varchar2(100),
    store_tel varchar2(20),
    store_time varchar2(50),
    original_filename varchar2(1000),
    like_cnt number default 0
);

create sequence board_food_seq;

create table reply_food_tb (
	reply_num number primary key,
	board_num number references board_food_tb,
	member_id varchar2(100) references member_food_tb(member_id),
	reply_content varchar2(1000),
	reply_indate date default sysdate
);

create sequence reply_food_seq;

alter table board_food_tb add(like_cnt number default 0);
commit;

insert into reply_food_tb
values (1, 'hong1', 'dd', sysdate);