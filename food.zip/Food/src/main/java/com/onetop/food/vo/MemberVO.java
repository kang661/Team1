package com.onetop.food.vo;

import lombok.Data;

@Data
public class MemberVO {

	private String userId;
	private String userPw;
	private String userNm;
}
