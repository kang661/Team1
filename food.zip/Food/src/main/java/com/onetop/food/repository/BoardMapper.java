package com.onetop.food.repository;

public interface BoardMapper {

}
