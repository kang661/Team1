var isIdChecked = false;
function idChk()
{
	var a = 10;
	$.ajax({
		url: "/member/idChk",
		data:
		{
			idChk: $("#userId").val()
		},
		success: function(res)
		{
			a += 10;
			if(res == "available")
			{
				isIdChecked = confirm("회원가입이 가능한 ID입니다. 사용하시겠습니까?");
				if(isIdChecked)
				{
					$("#userId").attr("readonly", "readonly");
					$("input:button").attr("disabled", "disabled");
				}
			}
			else
			{
				alert("이미 가입된 ID입니다.");
			}
		}
		});
		
			console.log(a);	
}
// 회원가입 페이지에서 사용자가 입력한 데이터의 유효성을 검사하는 함수
function formChk()
{

	var userId = $("#userId").val().trim(); // 사용자가 입력한 ID 값을 가져와서 공백을 제거하고 변수에 저장
	if(userId.length == 0) // ID를 입력하지 않은 경우
	{
		alert("ID를 입력해주세요.");
		return false;
	}

	if(userId.length < 3 || userId.length > 10) // ID를 3~10자리 사이로 입력하지 않은 경우
	{
		alert("ID는 3~10자리 사이로 입력해 주세요.");
		return false;
	}
				if(!isIdChecked)
	{
		alert("ID중복검사를 실시해주세요.");
		return false;
	}
	var userPw = $("#userPw").val().replaceAll(" ", ""); // 사용자가 입력한 PW값을 가져와서 공백을 제거하고 변수에 저장
	if(userPw.length == 0) // PW를 입력하지 않은 경우
	{
		alert("비밀번호를 입력해주세요.");
		return false;
	}
	if(userPw.length < 4 || userPw.length > 12)
	{
		alert("비밀번호는 4~12자리 사이로 입력해주세요."); // 비밀번호를 4~12자리 사이로 입력하지 않은 경우
		return false;
	}
	var userPwChk = $("#userPwChk").val().replaceAll(" ", "");
	if(userPw != userPwChk)
	{
		alert("비밀번호를 확인해주세요.");
		return false;
	} 
	// 모든 유효성 검사를 통화한 경우
	return true;
}