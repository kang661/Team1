package com.onetop.food.vo;

import lombok.Data;

@Data
public class ReplyVO {
	
	private int boardNum; // 게시글 번호
	private int replyNum; // 댓글 번호
	private String memberId; // 댓글 작성자
	private String replyContent; // 댓글 내용
	private String replyIndate; // 댓글 작성일

}