package com.onetop.food.vo;

import lombok.Data;

@Data
public class BoardVO {
	
	private int boardNum; // 게시글 번호
	private String boardTitle; // 게시글 제목
	private String boardContent; // 게시글 내용
	private String memberId; // 사용자 아이디
	private String boardDate; // 게시글 작성일
	private String boardMap; // 가게 주소
	private String originalFilename; // 파일 이름
	
	private String storeTel; // 가게 번호
	private String storeTime; // 가게 영업시간
	private int likeCnt; // 추천 수
}
