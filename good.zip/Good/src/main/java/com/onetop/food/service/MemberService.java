package com.onetop.food.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onetop.food.repository.MemberRepository;
import com.onetop.food.vo.MemberVO;

@Service
public class MemberService {

	@Autowired
	private MemberRepository rep;

	public boolean join(String memberId, String memberPw, String memberNm) 
	{
		MemberVO newMember = new MemberVO();
		newMember.setMemberId(memberId);
		newMember.setMemberPw(memberPw);
		newMember.setMemberNm(memberNm);
		
		return rep.join(newMember) > 0;
	}

	public String login(String memberId, String memberPw) 
	{
		MemberVO loginMember = new MemberVO();
		loginMember.setMemberId(memberId);
		loginMember.setMemberPw(memberPw);
		
		return rep.login(loginMember);
	}

	public String idChk(String idChk) 
	{
		return rep.idChk(idChk);
	}
}
