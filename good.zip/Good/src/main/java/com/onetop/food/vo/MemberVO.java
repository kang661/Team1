package com.onetop.food.vo;

import lombok.Data;

@Data
public class MemberVO {

	private String memberId;
	private String memberPw;
	private String memberNm;
	
}
