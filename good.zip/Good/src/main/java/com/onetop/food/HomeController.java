package com.onetop.food;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.onetop.food.service.BoardService;
import com.onetop.food.utill.PageNavigator;
import com.onetop.food.vo.BoardVO;


@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	private static final int COUNT_PER_PAGE = 10; // 한 페이지 당 보여줄 최대 게시글 수
	private static final int PAGE_PER_GROUP = 5; // 한 그룹 당 보여줄 최대 페이지 수
	
	@Autowired
	private BoardService service;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(@RequestParam(defaultValue = "1") int currentPage, Model model) {
		
		logger.info("jList 메소드(GET)");
		
		// 사용자가 보길 원하는 게시판 페이지 수를 확인(기본값 1)
		logger.info("현재 페이지(currentPage): {}", currentPage);
		
		// 검색종류 및 검색어를 입력해서 DB에서 총 게시글 수를 가져옴
		int totalRecordsCount = service.getTotalRecordsCount();
		logger.info("전체 게시글 수(totalRecordsCount): {}", totalRecordsCount);
		
		// 페이징 처리를 위한 내비게이터 객체 생성
		PageNavigator navi = new PageNavigator(COUNT_PER_PAGE, PAGE_PER_GROUP, currentPage, totalRecordsCount);
		logger.info("생성된 페이지 내비게이터(navi): {}", navi);
		model.addAttribute("navi", navi);
		
		ArrayList<BoardVO> result = service.readJList(navi.getStartRecord(), COUNT_PER_PAGE);
		logger.info("list: {}", result);
		model.addAttribute("list", result);
	
		return "home";
	}
	
}
