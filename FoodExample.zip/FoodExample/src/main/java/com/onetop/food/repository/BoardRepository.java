package com.onetop.food.repository;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.onetop.food.service.BoardService;
import com.onetop.food.vo.BoardVO;

@Repository
public class BoardRepository {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardRepository.class);
	
	@Autowired
	private SqlSession session;

	public ArrayList<BoardVO> readJList(HashMap<String, Object> map) {
		ArrayList<BoardVO> result = null;
		BoardMapper mapper = null;
		
		try {
			mapper = session.getMapper(BoardMapper.class);
			result = mapper.readJList(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	public ArrayList<BoardVO> searchBoard(HashMap<String, Object> map) {
		ArrayList<BoardVO> result = null;
		BoardMapper mapper = null;
		
		try {
			mapper = session.getMapper(BoardMapper.class);
			result = mapper.searchBoard(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	public int getTotalRecordsCount() {
		int result = 0;
		BoardMapper mapper = null;
		
		try {
			mapper = session.getMapper(BoardMapper.class);
			result = mapper.getTotalRecordsCount();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public int writeBoard(BoardVO newBoard) {
		int result = 0;
		BoardMapper mapper = null;
		
		logger.info("newBoard {}", newBoard);
		
		try {
			mapper = session.getMapper(BoardMapper.class);
			result = mapper.writeBoard(newBoard);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	// 읽기 기능
	public BoardVO readBoard(int boardNum) {
		
		BoardVO result = null;
		BoardMapper mapper = null;
		
		try
		{
			mapper = session.getMapper(BoardMapper.class);
			result = mapper.readBoard(boardNum);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return result;
	}
}
