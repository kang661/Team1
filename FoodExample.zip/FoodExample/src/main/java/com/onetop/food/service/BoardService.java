package com.onetop.food.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onetop.food.repository.BoardRepository;
import com.onetop.food.vo.BoardVO;

@Service
public class BoardService {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardService.class);
	
	@Autowired
	private BoardRepository rep;

	public ArrayList<BoardVO> readJList(int startRecord, int countPerPage) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("startRecord", startRecord);
		map.put("countPerPage", countPerPage);
		
		return rep.readJList(map);
	}

	public ArrayList<BoardVO> searchBoard(String searchType, String searchWord) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("searchType", searchType);
		map.put("searchWord", searchWord);
//		map.put("startRecord", startRecord);
//		map.put("countPerPage", countPerPage);
//		
		return rep.searchBoard(map);
	}

	public int getTotalRecordsCount() {
//		HashMap<String, Object> map = new HashMap<>();
//		map.put("searchType", searchType);
//		map.put("searchWorld", searchWorld);
		
		return rep.getTotalRecordsCount();
	}

	public boolean writeBoard(BoardVO newBoard, String logingId, String originalFilename, String savedFilename) {
		newBoard.setMemberId(logingId);
		newBoard.setOriginalFilename(originalFilename);
		newBoard.setSavedFilename(savedFilename);
		
		logger.info("newBoard {}", newBoard);
		
		return rep.writeBoard(newBoard) > 0;
	}

	public BoardVO readBoard(int boardNum) {
		
		return rep.readBoard(boardNum);
	}
}
