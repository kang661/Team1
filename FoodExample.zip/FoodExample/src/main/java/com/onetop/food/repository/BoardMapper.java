package com.onetop.food.repository;

import java.util.ArrayList;
import java.util.HashMap;

import com.onetop.food.vo.BoardVO;

public interface BoardMapper {

	ArrayList<BoardVO> readJList(HashMap<String, Object> map); // 일본 리스트 불러오기

	ArrayList<BoardVO> searchBoard(HashMap<String, Object> map); // 검색기능 

	int getTotalRecordsCount(); // 페이징

	int writeBoard(BoardVO newBoard); // 글 쓰기

	BoardVO readBoard(int boardNum); // 읽기 기능

}
